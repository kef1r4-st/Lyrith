import QtQuick
import QtQuick.Controls
import Quickshell
import Quickshell.Wayland
import "../"
import "../reusables"

PanelWindow {
    id: root
    color: "transparent"

    property string wId: Quickshell.env("QS_WIDGET_ID") || "preview"
    property string wType: "time"
    property string wVariant: ""
    property string wImagePath: ""
    property real wX: 0
    property real wY: 0
    property real wWidth: 250
    property real wHeight: 120
    property real wOpacity: 1.0
    property real wRotation: 0

    property var customProps: ({})

    readonly property real auraMargin: 8

    readonly property bool isSelected: typeof DesktopMenuController !== "undefined"
        && DesktopMenuController.isVisible
        && DesktopMenuController.mode === "widget"
        && DesktopMenuController.targetWidgetId === String(root.wId)
        && (!DesktopMenuController.screen || !root.screen || !DesktopMenuController.screen.name || !root.screen.name || DesktopMenuController.screen.name === root.screen.name)

    function applyCustomProps() {
        let it = faceLoader.item;
        if (!it || !customProps) return;
        let ignoredProps = [
            "objectName", "destroyed", "deleteLater", "parent", "data",
            "resources", "children", "visible", "enabled", "x", "y", "z",
            "width", "height", "opacity", "rotation", "scale"
        ];
        for (let k in customProps) {
            if (!k || typeof k !== "string") continue;
            if (k.endsWith("Changed") || k.startsWith("on") || typeof customProps[k] === "function" || customProps[k] === undefined) continue;
            if (ignoredProps.includes(k)) continue;
            try {
                if (it[k] !== undefined && it[k] !== customProps[k]) {
                    it[k] = customProps[k];
                }
            } catch (e) {}
        }
    }

    onCustomPropsChanged: applyCustomProps()

    property bool isRedacting: false
    property bool initialized: false

    property bool wantsKeyboardFocus: false
    readonly property bool effectiveKeyboardFocus: wantsKeyboardFocus || (faceLoader.item && (faceLoader.item.wantsKeyboardFocus || faceLoader.item.keyboardFocus || faceLoader.item.isEditingUser)) || false

    property real animX: wX
    property real animY: wY
    Behavior on animX {
        enabled: root.initialized && !root.isRedacting
        NumberAnimation {
            duration: 400
            easing.type: Easing.OutCubic
        }
    }
    Behavior on animY {
        enabled: root.initialized && !root.isRedacting
        NumberAnimation {
            duration: 400
            easing.type: Easing.OutCubic
        }
    }

    property real effectiveWidth: wWidth
    property real effectiveHeight: wHeight

    onWWidthChanged: updateEffectiveSize()
    onWHeightChanged: updateEffectiveSize()
    onWVariantChanged: updateEffectiveSize()
    onWTypeChanged: updateEffectiveSize()

    WlrLayershell.namespace: "qs-widget-" + wType + "-" + wId
    WlrLayershell.layer: WlrLayer.Bottom
    WlrLayershell.keyboardFocus: effectiveKeyboardFocus ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None

    exclusionMode: ExclusionMode.Ignore
    focusable: effectiveKeyboardFocus

    onEffectiveKeyboardFocusChanged: {
        if (effectiveKeyboardFocus && typeof root.requestActivate === "function") {
            root.requestActivate();
        }
    }

    anchors.top: true
    anchors.left: true
    margins.left: root.lyricsMenuExpanded ? root.lyricsMenuGlobalX - root.auraMargin : animX - root.auraMargin
    margins.top: root.lyricsMenuExpanded ? root.lyricsMenuGlobalY - root.auraMargin : animY - root.auraMargin

    readonly property real baseWindowWidth: ((Math.round(wRotation || 0) % 180 === 0) ? effectiveWidth : effectiveHeight) + (root.auraMargin * 2)
    readonly property real baseWindowHeight: ((Math.round(wRotation || 0) % 180 === 0) ? effectiveHeight : effectiveWidth) + (root.auraMargin * 2)
    // Keep the layer window expanded until the popup exit animation has fully finished.
    property bool lyricsMenuExpanded: false
    readonly property string lyricsMenuFontFamily: faceLoader.item && faceLoader.item.fontFamily ? faceLoader.item.fontFamily : "sans-serif"
    // Never force a minimum larger than the actual screen: the menu must stay inside it.
    readonly property real lyricsMenuWidth: Math.max(1, Math.min(390, (root.screen ? root.screen.width : 1920) - 64))
    readonly property real lyricsMenuHeight: Math.max(1, Math.min(300, (root.screen ? root.screen.height : 1080) - 64))
    readonly property real lyricsScreenWidth: root.screen ? root.screen.width : 1920
    readonly property real lyricsScreenHeight: root.screen ? root.screen.height : 1080
    readonly property real lyricsMenuGlobalX: Math.max(32, Math.min(animX + effectiveWidth / 2 - lyricsMenuWidth / 2, lyricsScreenWidth - lyricsMenuWidth - 32))
    readonly property real lyricsMenuGlobalY: Math.max(32, Math.min(animY + effectiveHeight / 2 - lyricsMenuHeight / 2, lyricsScreenHeight - lyricsMenuHeight - 32))
    implicitWidth: lyricsMenuExpanded ? Math.max(baseWindowWidth, lyricsMenuWidth + auraMargin * 2) : baseWindowWidth
    implicitHeight: lyricsMenuExpanded ? Math.max(baseWindowHeight, lyricsMenuHeight + auraMargin * 2) : baseWindowHeight

    Component.onCompleted: {
        Qt.callLater(() => {
            root.initialized = true;
        });
    }

    Component.onDestruction: {
        visible = false;
        faceLoader.active = false;
        faceLoader.source = "";
    }

    function updateEffectiveSize() {
        if (!faceLoader.item) {
            root.effectiveWidth = root.wWidth;
            root.effectiveHeight = root.wHeight;
            return;
        }
        let item = faceLoader.item;
        let c = {
            minW: item.minWidth !== undefined ? item.minWidth : 10,
            minH: item.minHeight !== undefined ? item.minHeight : 10,
            maxW: item.maxWidth !== undefined ? item.maxWidth : 9999,
            maxH: item.maxHeight !== undefined ? item.maxHeight : 9999,
            minA: item.minAspect !== undefined ? item.minAspect : 0,
            maxA: item.maxAspect !== undefined ? item.maxAspect : 9999
        };
        let w = Math.max(c.minW, Math.min(c.maxW, root.wWidth));
        let h = Math.max(c.minH, Math.min(c.maxH, root.wHeight));

        let ratio = w / h;
        if (ratio < c.minA && c.minA > 0) {
            let mA = c.minA;
            let hProj = (w * mA + h) / (mA * mA + 1);
            let hMin = Math.max(c.minH, c.minW / mA);
            let hMax = Math.min(c.maxH, c.maxW / mA);
            h = Math.max(hMin, Math.min(hMax, hProj));
            w = h * mA;
        } else if (ratio > c.maxA && c.maxA > 0) {
            let mA = c.maxA;
            let hProj = (w * mA + h) / (mA * mA + 1);
            let hMin = Math.max(c.minH, c.minW / mA);
            let hMax = Math.min(c.maxH, c.maxW / mA);
            h = Math.max(hMin, Math.min(hMax, hProj));
            w = h * mA;
        }

        w = Math.max(c.minW, Math.min(c.maxW, w));
        h = Math.max(c.minH, Math.min(c.maxH, h));

        root.effectiveWidth = w;
        root.effectiveHeight = h;
    }

    Loader {
        id: faceLoader
        property string wImagePath: root.wImagePath
        property string imagePath: root.wImagePath
        property string path: root.wImagePath
        visible: root.visible
        source: WidgetRegistry.faceFile(root.wType, root.wVariant)
        width: root.effectiveWidth
        height: root.effectiveHeight
        anchors.centerIn: parent
        anchors.horizontalCenterOffset: root.lyricsMenuExpanded ? (root.animX + root.effectiveWidth / 2 - root.lyricsMenuGlobalX + root.auraMargin - root.implicitWidth / 2) : 0
        anchors.verticalCenterOffset: root.lyricsMenuExpanded ? (root.animY + root.effectiveHeight / 2 - root.lyricsMenuGlobalY + root.auraMargin - root.implicitHeight / 2) : 0
        rotation: root.wRotation || 0
        opacity: root.wOpacity
        Behavior on opacity { NumberAnimation { duration: 150 } }
        Behavior on rotation { NumberAnimation { duration: 150; easing.type: Easing.OutQuad } }
        onLoaded: {
            if (item) {
                try {
                    item.visible = Qt.binding(() => root.visible);
                    if (item.imagePath !== undefined) {
                        item.imagePath = Qt.binding(() => root.wImagePath);
                    }
                    if (item.wImagePath !== undefined) {
                        item.wImagePath = Qt.binding(() => root.wImagePath);
                    }
                    if (item.path !== undefined) {
                        item.path = Qt.binding(() => root.wImagePath);
                    }
                    if (item.source !== undefined && typeof item.source === "string") {
                        item.source = Qt.binding(() => root.wImagePath);
                    }
                } catch (e) {}
            }
            root.applyCustomProps();
            root.updateEffectiveSize();
        }
    }

    Item {
        id: auraContainer
        width: faceLoader.width + (root.auraMargin * 2)
        height: faceLoader.height + (root.auraMargin * 2)
        anchors.centerIn: faceLoader
        rotation: faceLoader.rotation
        visible: opacity > 0.001
        opacity: root.isSelected ? 1.0 : 0.0

        Behavior on opacity {
            NumberAnimation {
                duration: 150
                easing.type: Easing.OutQuad
            }
        }

        SelectionOutline {
            anchors.fill: parent
            running: root.isSelected && auraContainer.opacity > 0.001
        }
    }


    function setLyricsSetting(name, value) {
        if (root.wType !== "asciiLyrics") return;
        if (faceLoader.item && faceLoader.item[name] !== undefined)
            faceLoader.item[name] = value;
        if (typeof WidgetSync !== "undefined" && root.screen && root.screen.name)
            WidgetSync.setProperty(root.screen.name, String(root.wId), name, value);
    }

    TapHandler {
        enabled: root.wType === "asciiLyrics" && !root.isRedacting
        acceptedButtons: Qt.LeftButton
        onTapped: {
            if (tapCount === 3) minecraftLyricsSettingsPopup.open();
        }
    }

    Popup {
        id: minecraftLyricsSettingsPopup
        parent: root.contentItem
        x: root.auraMargin
        y: root.auraMargin
        width: root.lyricsMenuWidth
        height: root.lyricsMenuHeight
        modal: true
        dim: false
        focus: true
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
        padding: 0
        readonly property bool glassMode: faceLoader.item ? faceLoader.item.menuGlassEnabled !== false : true

        // Expand the layer surface once and keep its origin stable after closing.
        // Shrinking/repositioning a Wayland layer surface causes a visible one-frame jump.
        onAboutToShow: root.lyricsMenuExpanded = true

        enter: Transition {
            ParallelAnimation {
                NumberAnimation {
                    target: minecraftLyricsSettingsPopup.contentItem
                    property: "opacity"
                    from: 0
                    to: 1
                    duration: 260
                    easing.type: Easing.OutCubic
                }
                NumberAnimation {
                    target: minecraftLyricsSettingsPopup.background
                    property: "opacity"
                    from: 0
                    to: 1
                    duration: 260
                    easing.type: Easing.OutCubic
                }
            }
        }
        exit: Transition {
            ParallelAnimation {
                NumberAnimation {
                    target: minecraftLyricsSettingsPopup.contentItem
                    property: "opacity"
                    from: 1
                    to: 0
                    duration: 520
                    easing.type: Easing.InOutSine
                }
                NumberAnimation {
                    target: minecraftLyricsSettingsPopup.background
                    property: "opacity"
                    from: 1
                    to: 0
                    duration: 520
                    easing.type: Easing.InOutSine
                }
            }
        }

        background: Rectangle {
            id: lyricsMenuBackground
            radius: 11
            property Item glassBackdropItem: menuBackdrop
            color: glassFill.active
                ? "transparent"
                : Qt.alpha("#1e1e2e", faceLoader.item && faceLoader.item.menuOpacity !== undefined ? faceLoader.item.menuOpacity : 0.86)
            border.width: 1
            border.color: Qt.alpha("#a6adc8", 0.48)
            clip: true

            WallpaperBlur {
                id: menuBackdrop
                anchors.fill: parent
                standalone: true
                blurStrength: 0.9
                tint: 0.12
                radius: parent.radius
                opacity: minecraftLyricsSettingsPopup.glassMode
                    ? 1
                    : (faceLoader.item && faceLoader.item.menuOpacity !== undefined ? faceLoader.item.menuOpacity : 0.86)
            }

            Rectangle {
                anchors.fill: parent
                radius: parent.radius
                color: "#1e1e2e"
                opacity: minecraftLyricsSettingsPopup.glassMode
                    ? 0.34
                    : (faceLoader.item && faceLoader.item.menuOpacity !== undefined ? faceLoader.item.menuOpacity : 0.86)
            }

            GlassFill {
                id: glassFill
                anchors.fill: parent
                radius: parent.radius
                // The menu already has WallpaperBlur; avoid a second live glass sampler here.
                allowed: false
                opacity: minecraftLyricsSettingsPopup.glassMode
                    ? 1
                    : (faceLoader.item && faceLoader.item.menuOpacity !== undefined ? faceLoader.item.menuOpacity : 0.86)
                tintColor: "#1e1e2e"
                tintAmount: 0.34
                frost: 2.8
                rim: 0.28
            }

            Rectangle {
                anchors.fill: parent
                radius: parent.radius
                color: "transparent"
                border.width: 1
                border.color: Qt.alpha("#cdd6f4", 0.08)
            }
        }

        Column {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 8

            Item {
                width: parent.width
                height: 32

                Text {
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Настройки текста"
                    color: "#cdd6f4"
                    font.family: root.lyricsMenuFontFamily
                    font.pixelSize: 13
                }

                Rectangle {
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    width: 28
                    height: 28
                    radius: 7
                    color: closeArea.containsMouse ? "#45475a" : "#313244"
                    Text {
                        anchors.centerIn: parent
                        text: "×"
                        color: "#cdd6f4"
                        font.pixelSize: 18
                    }
                    MouseArea {
                        id: closeArea
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: minecraftLyricsSettingsPopup.close()
                    }
                }
            }

            Rectangle { width: parent.width; height: 1; color: "#38384a" }

            Flickable {
                id: settingsScroll
                width: parent.width
                height: Math.max(80, parent.height - 94)
                clip: true
                contentWidth: width
                contentHeight: settingsRow.implicitHeight
                boundsBehavior: Flickable.StopAtBounds
                flickableDirection: Flickable.VerticalFlick

                Row {
                    id: settingsRow
                    width: settingsScroll.width
                    spacing: 12

                    Column {
                        width: (settingsRow.width - settingsRow.spacing - 1) * 0.49
                        spacing: 8

                        Text {
                            text: "Основной цвет"
                            color: "#cdd6f4"
                            font.family: root.lyricsMenuFontFamily
                            font.pixelSize: 9
                        }

                        Grid {
                            columns: 4
                            spacing: 6
                            Repeater {
                                model: [
                                    "#ffffff", "#eeeeee", "#ff5c5c", "#ff9f43",
                                    "#ffd43b", "#a9e34b", "#40c057", "#20c997",
                                    "#22d3ee", "#4dabf7", "#5c7cfa", "#be4bdb"
                                ]
                                delegate: Rectangle {
                                    required property string modelData
                                    width: 22
                                    height: 22
                                    radius: 6
                                    color: modelData
                                    border.width: faceLoader.item && String(faceLoader.item.ink) === modelData ? 2 : 1
                                    border.color: faceLoader.item && String(faceLoader.item.ink) === modelData ? "#f8f9fa" : "#62627a"
                                    MouseArea {
                                        anchors.fill: parent
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: root.setLyricsSetting("ink", modelData)
                                    }
                                }
                            }
                        }

                        Rectangle { width: parent.width; height: 1; color: "#38384a" }

                        Text {
                            text: "Вторичный цвет"
                            color: "#cdd6f4"
                            font.family: root.lyricsMenuFontFamily
                            font.pixelSize: 9
                        }

                        Grid {
                            columns: 4
                            spacing: 6
                            Repeater {
                                model: [
                                    "#a6a6a6", "#737373", "#ff8787", "#ffa94d",
                                    "#ffe066", "#b2f2bb", "#69db7c", "#63e6be",
                                    "#66d9e8", "#74c0fc", "#91a7ff", "#da77f2"
                                ]
                                delegate: Rectangle {
                                    required property string modelData
                                    width: 22
                                    height: 22
                                    radius: 6
                                    color: modelData
                                    border.width: faceLoader.item && String(faceLoader.item.muted) === modelData ? 2 : 1
                                    border.color: faceLoader.item && String(faceLoader.item.muted) === modelData ? "#f8f9fa" : "#62627a"
                                    MouseArea {
                                        anchors.fill: parent
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: root.setLyricsSetting("muted", modelData)
                                    }
                                }
                            }
                        }
                    }

                    Rectangle { width: 1; height: settingsRow.implicitHeight; color: "#38384a" }

                    Column {
                        width: (settingsRow.width - settingsRow.spacing - 1) * 0.51 - 9
                        spacing: 9

                        Text {
                            text: "Размер текста"
                            color: "#cdd6f4"
                            font.family: root.lyricsMenuFontFamily
                            font.pixelSize: 9
                        }

                        Row {
                            width: parent.width
                            spacing: 4
                            Repeater {
                                model: ["Малый", "Средний", "Крупный"]
                                delegate: Rectangle {
                                    required property int index
                                    required property string modelData
                                    width: (parent.width - 8) / 3
                                    height: 30
                                    radius: 6
                                    color: faceLoader.item && faceLoader.item.textScale === index ? "#45475a" : "#313244"
                                    border.width: faceLoader.item && faceLoader.item.textScale === index ? 1 : 0
                                    border.color: "#89b4fa"
                                    Text {
                                        anchors.centerIn: parent
                                        text: modelData
                                        color: "#cdd6f4"
                                        font.family: root.lyricsMenuFontFamily
                                        font.pixelSize: 7
                                    }
                                    MouseArea {
                                        anchors.fill: parent
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: root.setLyricsSetting("textScale", index)
                                    }
                                }
                            }
                        }

                        Rectangle { width: parent.width; height: 1; color: "#38384a" }

                        Text {
                            text: "Отображение"
                            color: "#cdd6f4"
                            font.family: root.lyricsMenuFontFamily
                            font.pixelSize: 9
                        }

                        Repeater {
                            model: [
                                { label: "Название трека", prop: "showTrackInfo" },
                                { label: "Вторая строка", prop: "showSideText" },
                                { label: "Анимация", prop: "animationEnabled" }
                            ]
                            delegate: Item {
                                required property var modelData
                                width: parent.width
                                height: 30

                                Text {
                                    anchors.left: parent.left
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: modelData.label
                                    color: "#cdd6f4"
                                    font.family: root.lyricsMenuFontFamily
                                    font.pixelSize: 8
                                }

                                Rectangle {
                                    anchors.right: parent.right
                                    anchors.rightMargin: 5
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: 31
                                    height: 18
                                    radius: 9
                                    color: faceLoader.item && faceLoader.item[modelData.prop] !== false ? "#89b4fa" : "#45475a"

                                    Rectangle {
                                        width: 12
                                        height: 12
                                        radius: 6
                                        y: 3
                                        x: faceLoader.item && faceLoader.item[modelData.prop] !== false ? 16 : 3
                                        color: "#f5f5f5"
                                        Behavior on x { NumberAnimation { duration: 110; easing.type: Easing.OutCubic } }
                                    }
                                }

                                MouseArea {
                                    anchors.fill: parent
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: {
                                        let oldValue = faceLoader.item ? faceLoader.item[modelData.prop] : true;
                                        root.setLyricsSetting(modelData.prop, oldValue === false);
                                    }
                                }
                            }
                        }

                        Item {
                            id: opacitySettingsWrap
                            width: parent.width
                            height: minecraftLyricsSettingsPopup.glassMode ? 0 : opacitySettingsContent.implicitHeight
                            opacity: minecraftLyricsSettingsPopup.glassMode ? 0 : 1
                            clip: true
                            Behavior on height {
                                NumberAnimation { duration: 240; easing.type: Easing.InOutCubic }
                            }
                            Behavior on opacity {
                                NumberAnimation { duration: 170; easing.type: Easing.OutCubic }
                            }

                            Column {
                                id: opacitySettingsContent
                                width: parent.width
                                spacing: 4

                                Rectangle { width: parent.width; height: 1; color: "#38384a" }

                                Text {
                                    text: "Прозрачность"
                                    color: "#cdd6f4"
                                    font.family: root.lyricsMenuFontFamily
                                    font.pixelSize: 9
                                }

                                Row {
                                    width: parent.width
                                    spacing: 8
                                    Slider {
                                        id: menuOpacitySlider
                                        width: parent.width - opacityValue.width - 8
                                        height: 28
                                        implicitHeight: 28
                                        from: 0.2
                                        to: 1.0
                                        stepSize: 0.05
                                        snapMode: Slider.SnapAlways
                                        value: faceLoader.item && faceLoader.item.menuOpacity !== undefined ? faceLoader.item.menuOpacity : 0.86
                                        onValueChanged: {
                                            if (pressed)
                                                root.setLyricsSetting("menuOpacity", value);
                                        }
                                        background: Rectangle {
                                            x: menuOpacitySlider.leftPadding
                                            y: menuOpacitySlider.topPadding + menuOpacitySlider.availableHeight / 2 - height / 2
                                            width: menuOpacitySlider.availableWidth
                                            height: 5
                                            radius: 3
                                            color: "#585b70"
                                            border.width: 1
                                            border.color: "#6c7086"
                                            Rectangle {
                                                width: menuOpacitySlider.visualPosition * parent.width
                                                height: parent.height
                                                radius: 3
                                                color: "#89b4fa"
                                            }
                                        }
                                        handle: Rectangle {
                                            x: menuOpacitySlider.leftPadding + menuOpacitySlider.visualPosition * (menuOpacitySlider.availableWidth - width)
                                            y: menuOpacitySlider.topPadding + menuOpacitySlider.availableHeight / 2 - height / 2
                                            width: 16
                                            height: 16
                                            radius: 8
                                            color: menuOpacitySlider.pressed ? "#ffffff" : "#cdd6f4"
                                            border.width: 2
                                            border.color: "#89b4fa"
                                        }
                                    }
                                    Text {
                                        id: opacityValue
                                        text: Math.round(menuOpacitySlider.value * 100) + "%"
                                        color: "#a6adc8"
                                        font.family: root.lyricsMenuFontFamily
                                        font.pixelSize: 8
                                        anchors.verticalCenter: parent.verticalCenter
                                    }
                                }
                            }
                        }

                        Item {
                            width: parent.width
                            height: 27
                            Text {
                                anchors.left: parent.left
                                anchors.verticalCenter: parent.verticalCenter
                                text: "Матовое стекло"
                                color: "#cdd6f4"
                                font.family: root.lyricsMenuFontFamily
                                font.pixelSize: 8
                            }
                            Rectangle {
                                anchors.right: parent.right
                                anchors.rightMargin: 5
                                anchors.verticalCenter: parent.verticalCenter
                                width: 31
                                height: 18
                                radius: 9
                                color: faceLoader.item && faceLoader.item.menuGlassEnabled !== false ? "#89b4fa" : "#45475a"
                                Rectangle {
                                    width: 12
                                    height: 12
                                    radius: 6
                                    y: 3
                                    x: faceLoader.item && faceLoader.item.menuGlassEnabled !== false ? 16 : 3
                                    color: "#f5f5f5"
                                }
                            }
                            MouseArea {
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    let enabled = faceLoader.item ? faceLoader.item.menuGlassEnabled !== false : true;
                                    root.setLyricsSetting("menuGlassEnabled", !enabled);
                                }
                            }
                        }
                    }
                }
            }

            Rectangle { width: parent.width; height: 1; color: "#38384a" }

            Item {
                width: parent.width
                height: 28

                Rectangle {
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    width: 76
                    height: 27
                    radius: 7
                    color: doneArea.containsMouse ? "#585b70" : "#45475a"
                    Text {
                        anchors.centerIn: parent
                        text: "Готово"
                        color: "#cdd6f4"
                        font.family: root.lyricsMenuFontFamily
                        font.pixelSize: 8
                    }
                    MouseArea {
                        id: doneArea
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: minecraftLyricsSettingsPopup.close()
                    }
                }
            }
        }
    }

    MouseArea {
        id: widgetMenuArea
        // The layer surface stays expanded for a stable origin; keep input limited to the widget.
        x: faceLoader.x
        y: faceLoader.y
        width: faceLoader.width
        height: faceLoader.height
        acceptedButtons: Qt.RightButton | (DesktopMenuController.isVisible ? Qt.LeftButton : 0)
        enabled: !root.isRedacting
        onClicked: mouse => {
            if (mouse.button === Qt.RightButton) {
                DesktopMenuController.toggle(root.screen, (root.animX - root.auraMargin) + mouse.x, (root.animY - root.auraMargin) + mouse.y, "widget", root.wId);
            } else {
                DesktopMenuController.hide();
            }
        }
    }
}
