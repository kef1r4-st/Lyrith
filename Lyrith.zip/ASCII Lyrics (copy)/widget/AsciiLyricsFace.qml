import QtQuick
import "../../../"

Item {
    id: root
    anchors.fill: parent
    clip: true

    property real minWidth: 260
    property real minHeight: 88
    property real maxWidth: 900
    property real maxHeight: 300
    property real minAspect: 1.8
    property real maxAspect: 7
    property bool isRound: false
    property bool lyricsSubscribed: false

    property int textScale: 1
    property bool showTrackInfo: true
    property bool showSideText: true
    property bool animationEnabled: true
    property real menuOpacity: 0.86
    property bool menuGlassEnabled: true
    property color ink: ThemeBackend.text || "#cdd6f4"
    property color muted: ThemeBackend.subtext0 || "#a6adc8"
    readonly property string fontFamily: minecraftFont.status === FontLoader.Ready ? minecraftFont.name : "sans-serif"

    readonly property string targetMain: {
        if (!Lyrics.isMediaActive) return "";
        if (Lyrics.loading && !Lyrics.hasLyrics) return "…";
        if (!Lyrics.hasLyrics) return "";
        return splitLine(currentLine()).main;
    }
    readonly property string targetSide: {
        if (!Lyrics.isMediaActive || !Lyrics.hasLyrics) return "";
        return splitLine(currentLine()).side;
    }
    readonly property string targetSignature: targetMain + "\u001f" + targetSide

    property string shownMain: ""
    property string shownSide: ""

    FontLoader {
        id: minecraftFont
        source: "minecraft.ttf"
    }

    function splitLine(value) {
        const original = String(value || "").replace(/\s+/g, " ").trim();
        const matches = original.match(/\(([^()]*)\)/g) || [];
        const side = matches.map(function(part) {
            return part.slice(1, -1).trim();
        }).filter(Boolean).join(" · ");
        const main = original.replace(/\([^()]*\)/g, " ").replace(/\s+/g, " ").trim();
        return { main: main || (side ? "" : original), side: side };
    }

    function currentLine() {
        if (!Lyrics.hasLyrics || !Lyrics.lyrics || Lyrics.lyrics.length === 0) return "";

        // Keep the widget empty until the first lyric timestamp is reached.
        // Do not preview line 0 during the instrumental intro.
        if (Lyrics.currentIndex < 0) return "";
        const startIndex = Lyrics.currentIndex;
        for (let i = startIndex; i < Lyrics.lyrics.length; i++) {
            const entry = Lyrics.lyrics[i];
            if (!entry) continue;
            const line = String(entry.text || "").trim();
            if (line) return line;
            const words = entry.words && entry.words.length
                ? entry.words.map(function(word) { return word.text || ""; }).join("").trim()
                : "";
            if (words) return words;
        }
        return "";
    }

    function updateLyrics() {
        // Text changes immediately; the animation is only visual.
        shownMain = targetMain;
        shownSide = targetSide;
        lyricEnter.stop();
        if (!animationEnabled) {
            lyricColumn.opacity = (shownMain.length > 0 || shownSide.length > 0) ? 1 : 0;
            lyricColumn.y = 0;
            lyricColumn.scale = 1;
            return;
        }
        lyricColumn.opacity = (shownMain.length > 0 || shownSide.length > 0) ? 0.35 : 0;
        lyricColumn.y = 4;
        lyricColumn.scale = 0.985;
        lyricEnter.restart();
    }

    function syncSubscription() {
        if (visible && !lyricsSubscribed) {
            lyricsSubscribed = true;
            Lyrics.subscribe();
        } else if (!visible && lyricsSubscribed) {
            lyricsSubscribed = false;
            Lyrics.unsubscribe();
        }
    }

    function animateTrackChange() {
        trackSwap.stop();
        trackEnter.stop();
        if (!animationEnabled || !trackInfo.visible) {
            trackInfo.shownText = trackInfo.targetText;
            trackInfo.opacity = 1;
            trackInfo.y = 0;
            return;
        }
        trackSwap.restart();
    }

    onVisibleChanged: syncSubscription()
    onTargetSignatureChanged: updateLyrics()
    Component.onCompleted: {
        syncSubscription();
        updateLyrics();
    }
    Component.onDestruction: {
        if (lyricsSubscribed) Lyrics.unsubscribe();
    }

    Item {
        id: idleScreen
        anchors.fill: parent
        visible: !Lyrics.isMediaActive
        opacity: visible ? 1 : 0
        Behavior on opacity {
            NumberAnimation { duration: 360; easing.type: Easing.OutCubic }
        }

        Row {
            anchors.centerIn: parent
            spacing: 7

            Text {
                text: "\uf09b"
                color: root.ink
                font.family: ThemeBackend.iconFont
                font.pixelSize: 19
                anchors.verticalCenter: parent.verticalCenter
            }

            Text {
                text: ".com/kef1r4-st"
                color: root.ink
                font.family: root.fontFamily
                font.pixelSize: 14
                anchors.verticalCenter: parent.verticalCenter
            }
        }
    }

    Column {
        id: content
        anchors.fill: parent
        opacity: Lyrics.isMediaActive ? 1 : 0
        Behavior on opacity {
            NumberAnimation { duration: 280; easing.type: Easing.OutCubic }
        }
        anchors.leftMargin: 5
        anchors.rightMargin: 5
        anchors.topMargin: 3
        spacing: 3

        Text {
            id: trackInfo
            property string targetText: {
                const artist = String(Lyrics.trackArtist || "").trim();
                const title = String(Lyrics.trackTitle || "").trim();
                return artist && title ? artist + " — " + title : (title || artist);
            }
            property string shownText: targetText
            width: parent.width
            height: visible ? 17 : 0
            visible: root.showTrackInfo && Lyrics.isMediaActive
            text: shownText
            color: root.muted
            font.family: root.fontFamily
            font.pixelSize: 11
            elide: Text.ElideRight
            wrapMode: Text.NoWrap
            verticalAlignment: Text.AlignVCenter

            onTargetTextChanged: root.animateTrackChange()
            onVisibleChanged: {
                trackSwap.stop();
                trackEnter.stop();
                if (visible) {
                    shownText = targetText;
                    opacity = 0;
                    y = 5;
                    trackEnter.restart();
                } else {
                    opacity = 0;
                    y = -5;
                }
            }

            SequentialAnimation {
                id: trackSwap
                ParallelAnimation {
                    NumberAnimation { target: trackInfo; property: "opacity"; to: 0; duration: 170; easing.type: Easing.InQuad }
                    NumberAnimation { target: trackInfo; property: "y"; to: -8; duration: 210; easing.type: Easing.InCubic }
                    NumberAnimation { target: trackInfo; property: "scale"; to: 0.96; duration: 190; easing.type: Easing.InCubic }
                }
                ScriptAction {
                    script: {
                        trackInfo.shownText = trackInfo.targetText;
                        trackInfo.y = 8;
                        trackInfo.scale = 1.04;
                    }
                }
                ParallelAnimation {
                    NumberAnimation { target: trackInfo; property: "opacity"; to: 1; duration: 300; easing.type: Easing.OutCubic }
                    NumberAnimation { target: trackInfo; property: "y"; to: 0; duration: 420; easing.type: Easing.OutBack }
                    NumberAnimation { target: trackInfo; property: "scale"; to: 1; duration: 380; easing.type: Easing.OutCubic }
                }
            }

            ParallelAnimation {
                id: trackEnter
                NumberAnimation { target: trackInfo; property: "opacity"; to: 1; duration: 300; easing.type: Easing.OutCubic }
                NumberAnimation { target: trackInfo; property: "y"; to: 0; duration: 420; easing.type: Easing.OutBack }
                NumberAnimation { target: trackInfo; property: "scale"; to: 1; duration: 380; easing.type: Easing.OutCubic }
            }
        }

        Item {
            id: lyricsViewport
            width: parent.width
            height: Math.max(0, parent.height - trackInfo.height - content.spacing - 3)
            clip: true

            Item {
                id: reveal
                width: parent.width
                height: Math.min(lyricColumn.implicitHeight, lyricsViewport.height)
                clip: true

                Column {
                    id: lyricColumn
                    width: parent.width
                    spacing: 2
                    opacity: 0
                    y: 8
                    scale: 0.97
                    transformOrigin: Item.TopLeft

                    Text {
                        id: lyricText
                        width: parent.width
                        text: root.shownMain
                        color: root.ink
                        font.family: root.fontFamily
                        font.pixelSize: root.textScale === 0 ? 13 : root.textScale === 2 ? 18 : 15
                        lineHeight: 1.0
                        wrapMode: Text.WordWrap
                        maximumLineCount: root.shownSide.length > 0 ? 3 : 4
                        elide: Text.ElideRight
                        horizontalAlignment: Text.AlignLeft
                        verticalAlignment: Text.AlignTop
                    }

                    Text {
                        id: sideText
                        width: parent.width
                        visible: root.showSideText && root.shownSide.length > 0
                        text: "(" + root.shownSide + ")"
                        color: root.muted
                        font.family: root.fontFamily
                        font.pixelSize: 10
                        wrapMode: Text.WordWrap
                        maximumLineCount: 1
                        elide: Text.ElideRight
                    }
                }
            }
        }
    }

    ParallelAnimation {
        id: lyricEnter
        running: false
        NumberAnimation {
            target: lyricColumn
            property: "opacity"
            to: (root.shownMain.length > 0 || root.shownSide.length > 0) ? 1 : 0
            duration: 170
            easing.type: Easing.OutCubic
        }
        NumberAnimation {
            target: lyricColumn
            property: "y"
            to: 0
            duration: 190
            easing.type: Easing.OutCubic
        }
        NumberAnimation {
            target: lyricColumn
            property: "scale"
            to: 1
            duration: 190
            easing.type: Easing.OutCubic
        }
    }
}
