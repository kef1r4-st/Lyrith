#!/usr/bin/env python3
from pathlib import Path
import re

WIDGETS = Path.home() / ".local/share/serpantinum/src/quickshell/widgets"
REGISTRY = WIDGETS / "WidgetRegistry.qml"
QMDIR = WIDGETS / "faces/qmldir"
WRAPPER = WIDGETS / "Widget.qml"
WRAPPER_BACKUP = WRAPPER.with_name("Widget.qml.ascii-lyrics.bak")
FACE_DIR = WIDGETS / "faces/music"

if REGISTRY.exists():
    text = REGISTRY.read_text(encoding="utf-8")
    text, count = re.subn(r'        "asciiLyrics": \{.*?        \},\n', '', text, count=1, flags=re.S)
    if count:
        REGISTRY.write_text(text, encoding="utf-8")

if QMDIR.exists():
    text = QMDIR.read_text(encoding="utf-8")
    text = text.replace("AsciiLyricsFace 1.0 music/AsciiLyricsFace.qml\n", "")
    QMDIR.write_text(text, encoding="utf-8")

if WRAPPER_BACKUP.exists():
    WRAPPER_BACKUP.replace(WRAPPER)

for name in ("AsciiLyricsFace.qml", "minecraft.ttf", "grass_block_side.png", "inventory_panel.png", "inventory_slot.png", "inventory_button.png", "inventory_button_hover.png", "inventory_tab.png", "music_disc.png", "mc_panel.png", "mc_slot.png", "mc_button.png", "mc_button_disabled.png"):
    target = FACE_DIR / name
    if target.exists():
        target.unlink()

print("Minecraft Lyrics удалён. Резервные копии и раскладка рабочего стола сохранены.")
