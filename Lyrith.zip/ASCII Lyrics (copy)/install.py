#!/usr/bin/env python3
from pathlib import Path
import shutil
import subprocess
import sys

PROJECT = Path(__file__).resolve().parent
WIDGET_SOURCE = PROJECT / "widget" / "AsciiLyricsFace.qml"
FONT_SOURCE = PROJECT / "assets" / "minecraft.ttf"
WRAPPER_SOURCE = PROJECT / "integration" / "Widget.qml"

WIDGETS = Path.home() / ".local/share/serpantinum/src/quickshell/widgets"
REGISTRY = WIDGETS / "WidgetRegistry.qml"
QMDIR = WIDGETS / "faces/qmldir"
FACE_DIR = WIDGETS / "faces/music"
FACE = FACE_DIR / "AsciiLyricsFace.qml"
FONT = FACE_DIR / "minecraft.ttf"
WRAPPER = WIDGETS / "Widget.qml"

REGISTRY_BACKUP = REGISTRY.with_name("WidgetRegistry.qml.ascii-lyrics.bak")
QMDIR_BACKUP = QMDIR.with_name("qmldir.ascii-lyrics.bak")
WRAPPER_BACKUP = WRAPPER.with_name("Widget.qml.ascii-lyrics.bak")
MARKER = '        "asciiLyrics": {'

for required in (WIDGET_SOURCE, FONT_SOURCE, WRAPPER_SOURCE, REGISTRY, QMDIR, WRAPPER):
    if not required.exists():
        sys.exit(f"Не найден обязательный файл: {required}")

if not REGISTRY_BACKUP.exists():
    shutil.copy2(REGISTRY, REGISTRY_BACKUP)
if not QMDIR_BACKUP.exists():
    shutil.copy2(QMDIR, QMDIR_BACKUP)
if not WRAPPER_BACKUP.exists():
    shutil.copy2(WRAPPER, WRAPPER_BACKUP)

registry_text = REGISTRY.read_text(encoding="utf-8")
if MARKER not in registry_text:
    entry = '''        "asciiLyrics": {
            name: "Minecraft Lyrics",
            icon: "#",
            category: "media",
            defaultWidth: 420,
            defaultHeight: 105,
            defaultVariant: "ascii",
            variants: {
                "ascii": { file: "faces/music/AsciiLyricsFace.qml", icon: "M", label: "Minecraft" }
            }
        },
'''
    anchor = '        "weather": {'
    if anchor not in registry_text:
        sys.exit("Не найдено место регистрации виджета; файлы системы не изменены.")
    REGISTRY.write_text(registry_text.replace(anchor, entry + anchor, 1), encoding="utf-8")

qm_text = QMDIR.read_text(encoding="utf-8")
qm_entry = "AsciiLyricsFace 1.0 music/AsciiLyricsFace.qml"
if qm_entry not in qm_text:
    QMDIR.write_text(qm_text.rstrip() + "\n" + qm_entry + "\n", encoding="utf-8")

FACE_DIR.mkdir(parents=True, exist_ok=True)
shutil.copy2(WIDGET_SOURCE, FACE)
shutil.copy2(FONT_SOURCE, FONT)
shutil.copy2(WRAPPER_SOURCE, WRAPPER)

shell = Path.home() / ".local/share/serpantinum/src/quickshell/Shell.qml"
if shell.exists():
    subprocess.run(["qs", "-p", str(shell), "ipc", "call", "main", "forceReload"], check=False)

print("Minecraft Lyrics установлен. Резервные копии реестра и qmldir сохранены.")
